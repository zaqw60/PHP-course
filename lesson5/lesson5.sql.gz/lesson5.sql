-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 07 2021 г., 17:12
-- Версия сервера: 10.5.11-MariaDB
-- Версия PHP: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lesson5`
--

-- --------------------------------------------------------

--
-- Структура таблицы `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `size` int(11) NOT NULL,
  `address` varchar(20) NOT NULL DEFAULT 'small_images',
  `count` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `gallery`
--

INSERT INTO `gallery` (`id`, `name`, `size`, `address`, `count`) VALUES
(1, '20170822_102304.jpg', 5170, 'small_images', 0),
(2, '20170822_111601.jpg', 7649, 'small_images', 0),
(3, '20170822_113355.jpg', 7939, 'small_images', 0),
(4, '20170822_114355.jpg', 8644, 'small_images', 0),
(5, '20170822_124029.jpg', 8374, 'small_images', 0),
(6, '20170822_124033.jpg', 8702, 'small_images', 0),
(7, '20170822_132229.jpg', 8651, 'small_images', 0),
(8, '20170822_154537.jpg', 7226, 'small_images', 0),
(9, '20170822_154716.jpg', 8395, 'small_images', 0),
(10, '20170822_163424.jpg', 6368, 'small_images', 0),
(11, '20170825_183407.jpg', 7651, 'small_images', 0),
(12, '20170825_183742.jpg', 8166, 'small_images', 0),
(13, '20170825_184230.jpg', 7068, 'small_images', 0),
(14, '20170823-WA0002.jpg', 7644, 'small_images', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
